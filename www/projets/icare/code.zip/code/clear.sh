#!/bin/bash

## This script erases all temporary files from the current folder
## in order to get a clean workspace before running a new computation

# Number of patches
nb_patch=2;

# Deleting '.comm' and '.export' local patches files
for n in `seq 1 $nb_patch`    
    do 
        rm local$n.export;
        rm patch$n.comm;
    done     
 
# Deleting temporary and output files
rm *.mess;
rm *.erre;
rm *.resu;
rm *.rmed;
rm *.pyc;
rm *~;
rm server.txt;
rm output.txt;
