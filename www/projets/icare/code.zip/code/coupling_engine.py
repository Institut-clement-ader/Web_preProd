import sys;
from mpi4py import MPI
import numpy as np


##########################################################'
# Etablissement de la communication MPI avec les modeles #
##########################################################'

# Communication avec le modele global
comm_port_global = MPI.Open_port (MPI.INFO_NULL);
service_global = "comm_global";
MPI.Publish_name(service_global, MPI.INFO_NULL, comm_port_global);
comm_global = MPI.COMM_SELF.Accept(comm_port_global, MPI.INFO_NULL);

# Echanges initiaux avec le modele global
maillage_global = comm_global.recv();


# Communication avec les modeles locaux
nb_patchs = 2;
comm_port_local = [None];
service_local = [None];
comm_local = [None];
for i in range(1,nb_patchs+1):
    comm_port_local.append(MPI.Open_port (MPI.INFO_NULL));
    service_local.append("comm_local_%i"%i);
    MPI.Publish_name(service_local[-1], MPI.INFO_NULL, comm_port_local[-1]);
    comm_local.append(MPI.COMM_SELF.Accept(comm_port_local[-1], MPI.INFO_NULL));
    
    
##########################################################'
#               Preparation du coupleur                  #
##########################################################'

# Envoi du maillage global aux patchs
for i in range(1,nb_patchs+1):
    comm_local[i].send(maillage_global); 
    
    
##########################################################'
#               Couplage et envois MPI                   #
##########################################################'

while (True):
    
    # Reception des deplacements du modele global            
    [ug, tag] = comm_global.recv(); 
    
    if (tag == 0):
        for i in range(1,nb_patchs+1):
            comm_local[i].send([None,tag]); 
        break;
            
    for i in range(1,nb_patchs+1):
        # Envoi du deplacement sur le modele local
        comm_local[i].send([ug[i],tag]);

    rl = [];
    for i in range(1,nb_patchs+1):        
        # Reception des efforts du modele local
        rl.append(comm_local[i].recv());        
    
    # Envoi de l'effort de correction sur le modele global    
    comm_global.send(rl);