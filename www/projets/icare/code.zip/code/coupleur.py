import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as splg

## ---------------------------------------------------------------------------##
## Classe correspondante au coupleur et contenant toutes ses variables
##----------------------------------------------------------------------------##
class Coupleur :
    

    """ Cette classe regroupe toutes les methodes et attributs relatifs au coupleur. """


    ## Constructeur de la classe
    def __init__ (self, maillage_global, maillage_local, num_patch) : 

        # Numero du patch considere
        self.num_patch = num_patch;
        
        # Maillages Python
        self.mailpyg = maillage_global;
        self.mailpyl = maillage_local;
        
        # Affectation des matrices de couplage a la classe 'Coupleur'
        self.matrice_C_G = self.Calc_Matr_Couplage_Global();
        self.matrice_C_L = self.Calc_Matr_Couplage_Local();
        
        
                
    # Calcul de la matrice de couplage locale     
    def Calc_Matr_Couplage_Local (self) :
        
        # Calcul de la matrice de masse condense sur le bord de la zone de couplage
        # Groupe de mailles 'GAMMA'
        # La variable 'm_gamma' contient un tableau listant le numero des mailles du groupe 'GAMMA'
        m_gamma =  self.mailpyl['gma']['GAMMA%d'%self.num_patch];
        # Groupe de noeuds 'GAMMA'
        # La variable 'n_gamma' contient un tableau listant le numero des noeuds du groupe 'GAMMA'
        n_gamma =  sorted(self.mailpyl['gno']['GAMMA%d'%self.num_patch]);
        # Table de connectivite
        table_connec = self.mailpyl['co'];
        # Coordonnees des noeuds du maillage
        coord = self.mailpyl['cn'];
        # Nombre de mailles de la frontiere 'GAMMA'
        nb_mailles = len(m_gamma);
        # Nombre de noeuds de la frontiere 'GAMMA'
        nb_noeuds = len(n_gamma);
        # Numerotation des noeuds
        num = {n_gamma[n] : n for n in range(nb_noeuds)};
        
        # Initialisation de la matrice de masse
        matrice_C = sp.lil_matrix((nb_noeuds,nb_noeuds));
        
        # On boucle sur l'ensemble des mailles de la frontiere 'GAMMA'
        for m in m_gamma :
            # On recupere les noeuds correspondant a la maille m
            noeuds = table_connec[m];
            i = noeuds[0];
            j = noeuds[1];
            # On recupere les coordonnees des noeuds i et j
            [xi, yi] = coord[i];
            [xj, yj] = coord[j];            
            # On mesure l'element m
            d = np.sqrt((xi-xj)**2 + (yi-yj)**2);
            # On assemble la matrice de masse
            matrice_C[num[i],num[i]] += d/3;
            matrice_C[num[j],num[j]] += d/3;
            matrice_C[num[i],num[j]] += d/6;
            matrice_C[num[j],num[i]] += d/6;
            
        matrice_C = matrice_C.tocsc();        
        matrice_C = splg.splu(matrice_C);
        
        return matrice_C;
              
                

    # Calcul de la matrice de couplage globale
    def Calc_Matr_Couplage_Global (self) :

        # Maillage global
        # Groupe de mailles 'GAMMA'
        # La variable 'm_gamma_l' contient un tableau listant le numero des mailles du groupe 'GAMMA'
        m_gamma_g =  self.mailpyg['gma']['GAMMA%d'%self.num_patch];
        # Groupe de noeuds 'GAMMA'
        # La variable 'n_gamma_g' contient un tableau listant le numero des noeuds du groupe 'GAMMA'
        n_gamma_g =  sorted(self.mailpyg['gno']['GAMMA%d'%self.num_patch]);
        # Nombre de noeuds de la frontiere 'GAMMA'
        nb_noeuds_g = len(n_gamma_g);
        # Coordonnees des noeuds du maillage
        coord_g = self.mailpyg['cn'];
        # Table de connectivite
        table_connec_g = self.mailpyg['co'];

        # Maillage local
        # Groupe de mailles 'GAMMA'
        # La variable 'm_gamma_l' contient un tableau listant le numero des mailles du groupe 'GAMMA'
        m_gamma_l =  self.mailpyl['gma']['GAMMA%d'%self.num_patch];
        # Groupe de noeuds 'GAMMA'
        # La variable 'n_gamma_l' contient un tableau listant le numero des noeuds du groupe 'GAMMA'
        n_gamma_l =  sorted(self.mailpyl['gno']['GAMMA%d'%self.num_patch]);
        # Table de connectivite
        table_connec_l = self.mailpyl['co'];
        # Coordonnees des noeuds du maillage
        coord_l = self.mailpyl['cn'];
        # Nombre de noeuds de la frontiere 'GAMMA'
        nb_noeuds_l = len(n_gamma_l);

        # Numerotation des noeuds
        numg = {n_gamma_g[n] : n for n in range(nb_noeuds_g)};
        numl = {n_gamma_l[n] : n for n in range(nb_noeuds_l)};

        # Initialisation de la matrice de couplage
        matrice_C = sp.lil_matrix((nb_noeuds_g,nb_noeuds_l));

        # On defini ici un fonction qui determine si un noeud donne est dans une maille donnee
        def Noeud_Dans_Maille (noeud, maille) :                
            # Coordonnees de 'noeud'    
            [nx, ny] = noeud;
            # On recupere les coordonnees des noeuds i et j de 'maille'
            [[nix, niy], 
             [njx, njy]] = maille;        
            # On cree le vecteur [n ni]
            n_nix = nix - nx;
            n_niy = niy - ny;
            # On cree le vecteur [n nj]
            n_njx = njx - nx;
            n_njy = njy - ny;
            # On calcule le produit scalaire 'n_ni . n_nj'
            ps = n_nix*n_njx + n_niy*n_njy;
            # On calcule le produit vectoriel 'n_ni x n_nj'
            pv = n_nix*n_njy - n_nix*n_njy;
            # Si (ps < 0) et (pv = 0), alors 'noeud' appartient a 'maille'
            # Remarque : en raison de la presence d'eventuelles erreurs machine, on affaiblie les test
            if ((ps < 1.0E-10) and (abs(pv) < 1.0E-10)) :
                return True;
            else : 
                return False;

        # On boucle sur les mailles globales
        for g in m_gamma_g :
            # On boucle sur les mailles locales
            for l in m_gamma_l :

                # On recupere les noeuds correspondant a la maille g
                noeuds_g = table_connec_g[g];
                gi = noeuds_g[0];
                gj = noeuds_g[1];
                # On recupere les coordonnees des noeuds i et j
                [gix, giy] = coord_g[gi];
                [gjx, gjy] = coord_g[gj];
        
                # On recupere les noeuds correspondant a la maille l
                noeuds_l = table_connec_l[l];
                li = noeuds_l[0];
                lj = noeuds_l[1];
                # On recupere les coordonnees des noeuds i et j
                [lix, liy] = coord_l[li];
                [ljx, ljy] = coord_l[lj];
                
                # Test d'appartenance des noeud 'li', 'lj' a la maille 'g'
                test_li = Noeud_Dans_Maille ([lix, liy], [[gix, giy],
                                                          [gjx, gjy]]);
                test_lj = Noeud_Dans_Maille ([ljx, ljy], [[gix, giy],
                                                          [gjx, gjy]]);
                # Test d'appartenance des noeud 'gi', 'gj' a la maille 'l'
                test_gi = Noeud_Dans_Maille ([gix, giy], [[lix, liy],
                                                          [ljx, ljy]]);
                test_gj = Noeud_Dans_Maille ([gjx, gjy], [[lix, liy],
                                                          [ljx, ljy]]);

                # On raisonne a present par disjonction de cas
                # au niveau de l'intersection des mailles 'g' et 'l'

                # L'intersection des mailles 'g' et 'l' est non vide
                if (test_li or test_lj or test_gi or test_gj) :

                    # L'une des maille est completement incluse dans l'autre
                    if ((test_li and test_lj) or (test_gi and test_gj)) :

                        # La maille 'l' est incluse dans la maille 'g'
                        if (test_li and test_lj) :

                            # On defini alors la maille 'g' comme la maille maitre et la maille 'l' comme la maille esclave
                            [[vix, viy], [vjx, vjy]] = [[gix, giy], [gjx, gjy]];
                            [[wix, wiy], [wjx, wjy]] = [[lix, liy], [ljx, ljy]];

                        # La maille 'g' est incluse dans la maille 'l'
                        elif (test_gi and test_gj) :

                            # On defini alors la maille 'l' comme la maille maitre et la maille 'g' comme la maille esclave
                            [[vix, viy], [vjx, vjy]] = [[lix, liy], [ljx, ljy]];
                            [[wix, wiy], [wjx, wjy]] = [[gix, giy], [gjx, gjy]];

                        # L'integrale de masse est calculee entre 'wi' et 'wj'

                        # Valeur de la fonction de forme 'Vi' au point 'wi'
                        fvi_wi = 1 - np.sqrt((vix-wix)**2 + (viy-wiy)**2)/np.sqrt((vix-vjx)**2 + (viy-vjy)**2);
                        # Valeur de la fonction de forme 'Vi' au point 'wj'
                        fvi_wj = 1 - np.sqrt((vix-wjx)**2 + (viy-wjy)**2)/np.sqrt((vix-vjx)**2 + (viy-vjy)**2);
                        # Valeur de la fonction de forme 'Vj' au point 'wi'
                        fvj_wi = 1 - np.sqrt((vjx-wix)**2 + (vjy-wiy)**2)/np.sqrt((vix-vjx)**2 + (viy-vjy)**2);
                        # Valeur de la fonction de forme 'Vj' au point 'wj'
                        fvj_wj = 1 - np.sqrt((vjx-wjx)**2 + (vjy-wjy)**2)/np.sqrt((vix-vjx)**2 + (viy-vjy)**2);

                        # Calcul de l'integrale 'Vi*Wi' sur [wi,wj] avec la formule de Simpson
                        matrice_C[numg[gi],numl[li]] += np.sqrt((wix-wjx)**2 + (wiy-wjy)**2)*(2*fvi_wi + fvi_wj)/6;
                        # Calcul de l'integrale 'Vj*Wj' sur [wi,wj] avec la formule de Simpson
                        matrice_C[numg[gj],numl[lj]] += np.sqrt((wix-wjx)**2 + (wiy-wjy)**2)*(2*fvj_wj + fvj_wi)/6;
                        # Calcul de l'integrale 'Vi*Wj' sur [wi,wj] avec la formule de Simpson
                        matrice_C[numg[gi],numl[lj]] += np.sqrt((wix-wjx)**2 + (wiy-wjy)**2)*(2*fvi_wj + fvi_wi)/6;
                        # Calcul de l'integrale 'Vj*Wi' sur [wi,wj] avec la formule de Simpson
                        matrice_C[numg[gj],numl[li]] += np.sqrt((wix-wjx)**2 + (wiy-wjy)**2)*(2*fvj_wi + fvj_wj)/6; 

                    # Les deux mailles se chevauchent partiellement
                    else :

                        # Le noeud 'li' appartient a la maille 'g' et le noeud 'gi' appartient a la maille 'l'
                        if ((test_li) and (test_gi)) :

                            # On renomme les variable pour se rammener au cas de reference
                            [g1, g2] = [gj, gi];
                            [[g1x, g1y], [g2x, g2y]] = [[gjx, gjy], [gix, giy]];
                            [l1, l2] = [li, lj];
                            [[l1x, l1y], [l2x, l2y]] = [[lix, liy], [ljx, ljy]];

                        # Le noeud 'lj' appartient a la maille 'g' et le noeud 'gi' appartient a la maille 'l'
                        elif ((test_lj) and (test_gi)) :

                            # On renomme les variable pour se rammener au cas de reference
                            [g1, g2] = [gj, gi];
                            [[g1x, g1y], [g2x, g2y]] = [[gjx, gjy], [gix, giy]];
                            [l1, l2] = [lj, li];
                            [[l1x, l1y], [l2x, l2y]] = [[ljx, ljy], [lix, liy]];

                        # Le noeud 'lj' appartient a la maille 'g' et le noeud 'gj' appartient a la maille 'l'
                        elif ((test_lj) and (test_gj)) :

                            # On renomme les variable pour se rammener au cas de reference
                            [g1, g2] = [gi, gj];
                            [[g1x, g1y], [g2x, g2y]] = [[gix, giy], [gjx, gjy]];
                            [l1, l2] = [lj, li];
                            [[l1x, l1y], [l2x, l2y]] = [[ljx, ljy], [lix, liy]];

                        # Le noeud 'li' appartient a la maille 'g' et le noeud 'gj' appartient a la maille 'l'
                        elif ((test_li) and (test_gj)) :

                            # On renomme les variable pour se rammener au cas de reference
                            [g1, g2] = [gi, gj];
                            [[g1x, g1y], [g2x, g2y]] = [[gix, giy], [gjx, gjy]];
                            [l1, l2] = [li, lj];
                            [[l1x, l1y], [l2x, l2y]] = [[lix, liy], [ljx, ljy]];

                        # L'integrale de masse est calculee entre 'l1' et 'g2'

                        # Valeur de la fonction de forme 'G2' au point 'l1'
                        fg2_l1 = 1 - np.sqrt((g2x-l1x)**2 + (g2y-l1y)**2)/np.sqrt((g2x-g1x)**2 + (g2y-g1y)**2); 
                        # Valeur de la fonction de forme 'L1' au point 'g2'
                        fl1_g2 = 1 - np.sqrt((g2x-l1x)**2 + (g2y-l1y)**2)/np.sqrt((l1x-l2x)**2 + (l1y-l2y)**2);
                        # Valeur de la fonction de forme 'G1' au point 'l1'
                        fg1_l1 = 1 - np.sqrt((g1x-l1x)**2 + (g1y-l1y)**2)/np.sqrt((g2x-g1x)**2 + (g2y-g1y)**2); 
                        # Valeur de la fonction de forme 'L2' au point 'g2'
                        fl2_g2 = 1 - np.sqrt((g2x-l2x)**2 + (g2y-l2y)**2)/np.sqrt((l1x-l2x)**2 + (l1y-l2y)**2); 

                        # Calcul de l'integrale 'G2*L1' sur [l1,g2] avec la formule de Simpson
                        matrice_C[numg[g2],numl[l1]] += np.sqrt((g2x-l1x)**2 + (g2y-l1y)**2)*(1 + 2*fg2_l1 + 2*fl1_g2 + fg2_l1*fl1_g2)/6;
                        # Calcul de l'integrale 'G1*L2' sur [l1,g2] avec la formule de Simpson
                        matrice_C[numg[g1],numl[l2]] += np.sqrt((g2x-l1x)**2 + (g2y-l1y)**2)*(fg1_l1*fl2_g2)/6;
                        # Calcul de l'integrale 'G2*L2' sur [l1,g2] avec la formule de Simpson
                        matrice_C[numg[g2],numl[l2]] += np.sqrt((g2x-l1x)**2 + (g2y-l1y)**2)*(2*fl2_g2 + fg2_l1*fl2_g2)/6;
                        # Calcul de l'integrale 'G1*L1' sur [l1,g2] avec la formule de Simpson
                        matrice_C[numg[g1],numl[l1]] += np.sqrt((g2x-l1x)**2 + (g2y-l1y)**2)*(2*fg1_l1 + fg1_l1*fl1_g2)/6;

        matrice_C = matrice_C.tocsr();   
                        
        return matrice_C;



    ## Operateur de projection du maillage local vers le maillage global 
    def Projection_Local_To_Global (self, vect) :

        [vect_x, vect_y] = vect;

        # Projection vers le modele global        
        p_vect_x = self.matrice_C_G.dot(self.matrice_C_L.solve(vect_x));
        p_vect_y = self.matrice_C_G.dot(self.matrice_C_L.solve(vect_y));
        
        return [p_vect_x, p_vect_y];



    ## Operateur de projection du maillage global vers le maillage local 
    def Projection_Global_To_Local (self, vect) :
        
        [vect_x, vect_y] = vect;

        # Projection vers le modele local        
        p_vect_x = self.matrice_C_L.solve(self.matrice_C_G.T.dot(vect_x));
        p_vect_y = self.matrice_C_L.solve(self.matrice_C_G.T.dot(vect_y));

        return [p_vect_x, p_vect_y];

