from Cata.cata import *  
from Accas import _F
from Utilitai.partition import *
import numpy as np


## We use the 'g' array for the storage of all Code_Aster concepts.
## AsterDim is the max number of storable concepts,
## and AsterCount is a Python iterator.
AsterDim = 1000000;       
g = [None]*AsterDim;
AsterCount = iter(range(AsterDim));

## ------------------------------------##
## Global model class
##-------------------------------------##
class ModeleGlobal :
    

    """ This class contains all the methods and attributes of the global model. """


    ## Class constructor
    def __init__ (self, nb_patch) : 

        global AsterDim, g, AsterCount;

        # Young's modulus
        self.E = 200.0E09;
        # Poisson's ratio
        self.nu = 0.3;
        # Tensile loading strenght
        self.p = 80.0E06;
        
        # Reading the mesh from the '.med' file
        mesh = LIRE_MAILLAGE (FORMAT = 'MED',
                              NOM_MED = 'STRUCTURE');
                              
        # Nodes groups are defined upon already existing boundary stitches groups
        mesh = DEFI_GROUP (reuse = mesh,
                           MAILLAGE = mesh,
                           CREA_GROUP_NO = _F (NOM = 'GAMMA',
                                               GROUP_MA = 'GAMMA',
                                               CRIT_NOEUD = 'TOUS'));   
        for i in range(nb_patch+1):
            mesh = DEFI_GROUP (reuse = mesh,
                               MAILLAGE = mesh,
                               CREA_GROUP_NO = _F (NOM = 'GAMMA%d'%i,
                                                   GROUP_MA = 'GAMMA%d'%i,
                                                   CRIT_NOEUD = 'TOUS'));  
                                          
        # Assignment of the mesh to the class 'ModeleGlobal'
        self.maillage = mesh;
        
        # Extracting the mesh into the Python workspace
        mailpy = MAIL_PY();
        mailpy.FromAster(self.maillage);
        self.mailpy = {'gma':mailpy.gma, 'gno':mailpy.gno, 'co':mailpy.co.data, 'cn':mailpy.cn, 'corresp':mailpy.correspondance_noeuds};
        
        # Material law definition (linear elastic)
        AsterIter = AsterCount.next();
        g[AsterIter] = DEFI_MATERIAU (ELAS = _F (E = self.E,
                                                 NU = self.nu));
        # Assignment of the material to the class
        self.materiau = g[AsterIter];

        # Applying the material to the structure
        AsterIter = AsterCount.next();
        g[AsterIter] = AFFE_MATERIAU (MAILLAGE = self.maillage,
                                      AFFE = _F (TOUT = 'OUI',
                                                 MATER = self.materiau));
        # Assignment of the materialised structure to the class
        self.champ_materiau = g[AsterIter];

        # Mechanical behaviour definition (plane strain)
        AsterIter = AsterCount.next();
        g[AsterIter] = AFFE_MODELE (MAILLAGE = self.maillage,
                                    AFFE = _F (TOUT = 'OUI',
                                               PHENOMENE = 'MECANIQUE', 
                                               MODELISATION = 'D_PLAN'));
        # Assignment of the mechanical behaviour to the class
        self.modele = g[AsterIter];
 
        # Global loading definition
        AsterIter = AsterCount.next(); 
        g[AsterIter] = AFFE_CHAR_MECA (MODELE = self.modele,
                                       DDL_IMPO = _F (GROUP_NO = ('REF_UP','REF_DOWN'),
                                                      LIAISON = 'ENCASTRE'), 
                                       FORCE_CONTOUR = _F (GROUP_MA = 'RIGHT',
                                                           FX = self.p));
        # Assignment of the global laoding to the class
        self.chargement = g[AsterIter];


        # Stiffness matrix and load vector assembly        
        AsterIter = AsterCount.next();  
        g[AsterIter] = CO('g_%d' % AsterIter);
        AsterIter = AsterCount.next(); 
        g[AsterIter] = CO('g_%d' % AsterIter);
        AsterIter = AsterCount.next(); 
        g[AsterIter] = CO('g_%d' % AsterIter);
        ASSEMBLAGE (MODELE = self.modele,
                    CHAM_MATER = self.champ_materiau,
                    CHARGE = self.chargement,
                    NUME_DDL = g[AsterIter-2],
                    MATR_ASSE = _F (MATRICE = g[AsterIter-1],
                                    OPTION = 'RIGI_MECA'),
                    VECT_ASSE = _F (VECTEUR = g[AsterIter],
                                    OPTION = 'CHAR_MECA'));       
        # Stiffness matrix factorisation
        g[AsterIter-1] = FACTORISER (reuse = g[AsterIter-1],
                                     MATR_ASSE = g[AsterIter-1]);        
        # Assignment of the dof numbering to the class
        self.numerotation_ddl = g[AsterIter-2]; 
        # Assignment of the stiffness matrix to the class
        self.matrice_K = g[AsterIter-1];
        # Assignment of the load vector to the class
        self.vecteur_F = g[AsterIter];



    ## Global problem solver with additional right hand side vector on the interface
    def Resolution (self, vect = None) :

        global g, AsterCount;
    
        if vect is None :
            # No additional right hand side vector
            AsterIter = AsterCount.next(); 
            g[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                       NUME_DDL = self.numerotation_ddl,
                                       OPERATION = 'COMB',
                                       COMB = (_F (CHAM_GD = self.vecteur_F,
                                                   COEF_R = 1.0)));
        else :
            # Additional right hand side vector (actually taking place of the initial load vector)
            AsterIter = AsterCount.next(); 
            g[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                       NUME_DDL = self.numerotation_ddl,
                                       OPERATION = 'COMB',
                                       COMB = (_F (CHAM_GD = self.vecteur_F,
                                                   COEF_R = 0.0),
                                               _F (CHAM_GD = vect,
                                                   COEF_R = 1.0)));

        # Linear system solving
        AsterIter = AsterCount.next(); 
        g[AsterIter] = RESOUDRE (MATR = self.matrice_K,
                       CHAM_NO = g[AsterIter-1]);

        return g[AsterIter];



    ## Computes the global model reaction forces
    def Calc_Reaction (self, vect_u) :

        # Creates a new result concept in the Code_Aster workspace
        AsterIter = AsterCount.next(); 
        g[AsterIter] = CREA_RESU (OPERATION = 'AFFE',
                                  TYPE_RESU = 'EVOL_ELAS',
                                  NOM_CHAM = 'DEPL',
                                  AFFE = _F (INST = 0.0,
                                             CHAM_GD = vect_u,
                                             MODELE = self.modele,
                                             CHAM_MATER = self.champ_materiau));  
                                             
        # Computes the stress field
        g[AsterIter] = CALC_CHAMP (reuse = g[AsterIter], 
                                   RESULTAT = g[AsterIter],
                                   CONTRAINTE = 'SIEF_ELGA',
                                   TOUT = 'OUI'); 
                   
        # Computes the generalised reaction forces from the solution
        g[AsterIter] = CALC_CHAMP (reuse = g[AsterIter], 
                                   RESULTAT = g[AsterIter],
                                   FORCE = 'FORC_NODA',
                                   GROUP_MA = 'OMEGA0');
        
        # Computes the Von Mises equivalent stress
        g[AsterIter] = CALC_CHAMP (reuse = g[AsterIter], 
                                   RESULTAT = g[AsterIter],
                                   CRITERES = 'SIEQ_ELGA',
                                   TOUT = 'OUI');
        self.Post = g[AsterIter];
        
        # Extracts the reaction field
        AsterIter = AsterCount.next(); 
        g[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                   OPERATION = 'EXTR',
                                   RESULTAT = g[AsterIter-1],
                                   NOM_CHAM = 'FORC_NODA');

        return g[AsterIter];

        
        
    ## Casts a Code_Aster field into Python vectors on the interface
    def ReprAster2Python (self, vect, num_patch) :

        global g, AsterCount;     
        
        vect_x = vect.EXTR_COMP('DX',['GAMMA%d'%num_patch],1).valeurs;
        vect_y = vect.EXTR_COMP('DY',['GAMMA%d'%num_patch],1).valeurs;
        
        return [vect_x, vect_y];
        
        
        
    ## Casts Python vectors into a Code_Aster field on the interface
    def ReprPython2Aster (self, vect, num_patch) :

        global g, AsterCount;    
        
        [vect_x, vect_y] = vect;
        
        # Interface nodes list
        noeuds =  ["".join(self.mailpy['corresp'][n]).rstrip() for n in sorted(self.mailpy['gno']['GAMMA%d'%num_patch])];
        
        # Casts the Python vectors into a Code_Aster table
        AsterIter = AsterCount.next(); 
        g[AsterIter] = CREA_TABLE (LISTE = (_F (LISTE_K = noeuds,
                                                PARA = 'NOEUD'),
                                            _F (LISTE_R = vect_x.tolist(),
                                                PARA = 'DX'),
                                            _F (LISTE_R = vect_y.tolist(),
                                                PARA = 'DY')));

        # Creates a Code_Aster field from the table
        AsterIter = AsterCount.next(); 
        g[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                   OPERATION = 'EXTR',
                                   PROL_ZERO = 'OUI',
                                   NUME_DDL = self.numerotation_ddl,
                                   TABLE = g[AsterIter-1],
                                   MAILLAGE = self.maillage);
        
        return g[AsterIter];  
        
        
        
    ## Combines the local and global reactions forces into a unique residual loading vector
    def Combiner_Effort (self, r) :    
        
        global g, AsterCount;            
        
        champslist = [];        
        for ind in range(len(r)) :
            champslist.append({'CHAM_GD' : self.ReprPython2Aster(r[ind], ind), 'COEF_R' : -1.0});

        # Creates the Code_Aster residual field to be sent to the global solver
        AsterIter = AsterCount.next(); 
        g[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                   PROL_ZERO = 'OUI',
                                   NUME_DDL = self.numerotation_ddl,
                                   OPERATION = 'COMB',
                                   COMB = champslist);

        return g[AsterIter];        