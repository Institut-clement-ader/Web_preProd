from Cata.cata import *  
from Accas import _F
from Utilitai.partition import *
import numpy as np


AsterDim = 1000000;       
l = [None]*AsterDim;
AsterCount = iter(range(AsterDim));

## ---------------------------------------------------------------------------##
## Local model class
##----------------------------------------------------------------------------##
class ModeleLocal :
    

    """ This class contains all the methods and attributes of the local model. """


    ## Class constructor
    def __init__ (self, num_patch) : 

        global AsterDim, l, AsterCount;

        # Young's modulus
        self.E = 200.0E09;
        # Poisson's ratio
        self.nu = 0.3;
        # Elastic limit
        self.K = 250.0E06;
        # Tangent elastic modulus (linear kinematic hardening)
        self.n = 0.2*self.E;
        # Tensile loading strenght
        self.p = 640.0E06/np.pi;
        
        # Patch number
        self.num_patch = num_patch;

        # Reading the mesh from the '.med' file
        AsterIter = AsterCount.next();
        l[AsterIter] = LIRE_MAILLAGE (FORMAT = 'MED',
                                      NOM_MED = 'PATCH%d'%num_patch);
        # Nodes groups are defined upon already existing boundary stitches groups                      
        l[AsterIter] = DEFI_GROUP (reuse = l[AsterIter],
                                   MAILLAGE = l[AsterIter],
                                   CREA_GROUP_NO = _F (NOM = 'GAMMA%d'%num_patch,
                                                       GROUP_MA = 'GAMMA%d'%num_patch,
                                                       CRIT_NOEUD = 'TOUS'));  
                                      
        # Assignment of the mesh to the class 'ModeleLocal'
        self.maillage = l[AsterIter];

        # Extracting the mesh into the Python workspace
        mailpy = MAIL_PY();
        mailpy.FromAster(self.maillage);
        self.mailpy = {'gma':mailpy.gma, 'gno':mailpy.gno, 'co':mailpy.co.data, 'cn':mailpy.cn, 'corresp':mailpy.correspondance_noeuds};
        
        # Material law definition (linear kinematic hardening) 
        AsterIter = AsterCount.next();     
        l[AsterIter] = DEFI_MATERIAU (ELAS = _F (E = self.E,
                                                 NU = self.nu),
                                      ECRO_LINE = _F (D_SIGM_EPSI = self.n,
                                                      SY = self.K));
        # Assignment of the material to the class
        self.materiau = l[AsterIter];

        # Applying the material to the structure
        AsterIter = AsterCount.next();  
        l[AsterIter] = AFFE_MATERIAU (MAILLAGE = self.maillage,
                                      AFFE = _F (TOUT = 'OUI',
                                                 MATER = self.materiau));
        # Assignment of the materialised structure to the class
        self.champ_materiau = l[AsterIter];

        # Mechanical behaviour definition (plane strain)
        AsterIter = AsterCount.next();  
        l[AsterIter] = AFFE_MODELE (MAILLAGE = self.maillage,
                                    AFFE = _F (TOUT = 'OUI',
                                               PHENOMENE = 'MECANIQUE', 
                                               MODELISATION = 'D_PLAN'));
        # Assignment of the mechanical behaviour to the class
        self.modele = l[AsterIter];

        # Dof numbering
        AsterIter = AsterCount.next();  
        l[AsterIter] = NUME_DDL (MODELE = self.modele);    
        # Assignment of the numbering to the class'
        self.numerotation_ddl = l[AsterIter];
        
        

    ## Local problem solver with prescribed Dirichlet condition on the interface
    def Resolution (self, depl_impo, tag) :

        global AsterDim, l, AsterCount;   
        
        
        if (self.num_patch == 1):
            
            # Loading definition for the first patch
            AsterIter = AsterCount.next();  
            l[AsterIter] = AFFE_CHAR_MECA (MODELE = self.modele,  
                                           CHAMNO_IMPO = _F (CHAM_NO = depl_impo, 
                                                             COEF_MULT = 1.0),
                                           DDL_IMPO = _F (GROUP_MA = 'LEFT',
                                                          LIAISON = 'ENCASTRE')); 
                
        elif (self.num_patch == 2):  
        
            # Loading definition for the second patch
            AsterIter = AsterCount.next();  
            l[AsterIter] = AFFE_CHAR_MECA (MODELE = self.modele,  
                                           CHAMNO_IMPO = _F (CHAM_NO = depl_impo, 
                                                             COEF_MULT = 1.0), 
                                           FORCE_CONTOUR = _F (GROUP_MA = 'RIGHT',
                                                               FX = self.p));
                                                               
        # Linear elastic behaviour
        if (tag == 1): 
            
            # Solving the local problem      
            AsterIter = AsterCount.next();   
            l[AsterIter] = MECA_STATIQUE (MODELE = self.modele,
                                          CHAM_MATER = self.champ_materiau,
                                          EXCIT = _F (CHARGE = l[AsterIter-1]));
            
            # Computes the generalised reaction forces from the solution 
            l[AsterIter] = CALC_CHAMP (reuse = l[AsterIter], 
                                    RESULTAT = l[AsterIter],
                                    FORCE = 'FORC_NODA',
                                    TOUT = 'OUI');
                                    
            # Computes the Von Mises equivalent stress                        
            l[AsterIter] = CALC_CHAMP (reuse = l[AsterIter], 
                                    RESULTAT = l[AsterIter],
                                    CRITERES = 'SIEQ_ELGA',
                                    TOUT = 'OUI');
            self.Post = l[AsterIter];
            
            # Extracts the displacement field
            AsterIter = AsterCount.next();                                 
            l[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                    OPERATION = 'EXTR',
                                    RESULTAT = l[AsterIter-1],
                                    NOM_CHAM = 'DEPL'); 
            u = l[AsterIter];
            
            # Extracts the reaction field      
            AsterIter = AsterCount.next(); 
            l[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                    OPERATION = 'EXTR',
                                    RESULTAT = l[AsterIter-2],
                                    NOM_CHAM = 'FORC_NODA');                               
            r = l[AsterIter];                                                                       

        # Elastic-plastic non-linear behaviour
        elif (tag == 2):
                                        
            # Load increments
            AsterIter = AsterCount.next();  
            l[AsterIter] = DEFI_LIST_REEL (DEBUT = 0.0,
                                        INTERVALLE = _F (JUSQU_A = 1.0,
                                                            NOMBRE = 10));

            # Solving the local problem
            AsterIter = AsterCount.next();  
            l[AsterIter] = STAT_NON_LINE (MODELE = self.modele,
                                        CHAM_MATER = self.champ_materiau,
                                        EXCIT = _F (CHARGE = l[AsterIter-2]),
                                        COMP_INCR = _F (RELATION = 'VMIS_CINE_LINE'),
                                        INCREMENT = _F (LIST_INST = l[AsterIter-1]),
                                        NEWTON = _F (REAC_ITER = 2),
                                        ARCHIVAGE = _F (INST = 1.0),
                                        CONVERGENCE = _F (ITER_GLOB_MAXI = 100));  
            
            # Computes the generalised reaction forces from the solution 
            l[AsterIter] = CALC_CHAMP (reuse = l[AsterIter], 
                                    RESULTAT = l[AsterIter],
                                    INST = 1.0,
                                    FORCE = 'FORC_NODA',
                                    TOUT = 'OUI');
            
            # Computes the Von Mises equivalent stress
            l[AsterIter] = CALC_CHAMP (reuse = l[AsterIter], 
                                    RESULTAT = l[AsterIter],
                                    INST = 1.0,
                                    CRITERES = 'SIEQ_ELGA',
                                    TOUT = 'OUI');
            self.Post = l[AsterIter]; 
            
            # # Extracts the displacement field  
            AsterIter = AsterCount.next();                                 
            l[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                    OPERATION = 'EXTR',
                                    INST = 1.0,
                                    RESULTAT = l[AsterIter-1],
                                    NOM_CHAM = 'DEPL'); 
            u = l[AsterIter];
            
            # Extracts the reaction field      
            AsterIter = AsterCount.next(); 
            l[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                    OPERATION = 'EXTR',
                                    INST = 1.0,
                                    RESULTAT = l[AsterIter-2],
                                    NOM_CHAM = 'FORC_NODA');                               
            r = l[AsterIter];                                                    
                                                      
                                   
        return [u,r];

        
        
    ## Casts a Code_Aster field into Python vectors on the interface    
    def ReprAster2Python (self, vect) :

        global l, AsterCount;     
        
        vect_x = vect.EXTR_COMP('DX',['GAMMA%d'%self.num_patch],1).valeurs;
        vect_y = vect.EXTR_COMP('DY',['GAMMA%d'%self.num_patch],1).valeurs;
        
        return [vect_x, vect_y];
        
        
        
    ## Casts Python vectors into a Code_Aster field on the interface   
    def ReprPython2Aster (self, vect) :

        global l, AsterCount;    
        
        [vect_x, vect_y] = vect;
        
        # Interface nodes list
        noeuds =  ["".join(self.mailpy['corresp'][n]).rstrip() for n in sorted(self.mailpy['gno']['GAMMA%d'%self.num_patch])];
        
        # Casts the Python vector into a Code_Aster table
        AsterIter = AsterCount.next(); 
        l[AsterIter] = CREA_TABLE (LISTE = (_F (LISTE_K = noeuds,
                                                PARA = 'NOEUD'),
                                            _F (LISTE_R = vect_x.tolist(),
                                                PARA = 'DX'),
                                            _F (LISTE_R = vect_y.tolist(),
                                                PARA = 'DY')));

        # Creates a Code_Aster field from the table
        AsterIter = AsterCount.next(); 
        l[AsterIter] = CREA_CHAMP (TYPE_CHAM = 'NOEU_DEPL_R',
                                   OPERATION = 'EXTR',
                                   TABLE = l[AsterIter-1],
                                   MAILLAGE = self.maillage);
        
        return l[AsterIter];  