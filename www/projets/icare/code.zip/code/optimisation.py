from Cata.cata import *  
from Accas import _F
from Utilitai.partition import *
import numpy as np


AsterDim = 1000000;       
o = [None]*AsterDim;
AsterCount = iter(range(AsterDim));

## ----------------------------------------------------------------------------##
## Classe correspondante aux outils de calcul et contenant toutes ses variables
##-----------------------------------------------------------------------------##
class Optimisation_Toolbox :
    

    """ Cette classe regroupe toutes les methodes et attributs relatifs aux outils d'optimisation.
        Elle permet d'utiliser les methodes d'acceleration de Quasi-Newton SR1 et Aitken's Delta Squared. """

          
    ## Constructeur de la classe
    def __init__ (self, modele_global) : 

        # Affectation du modele global a la classe 'Optimisation_Toolbox'
        self.mg = modele_global;
        
        # Reference pour le calcul du residu en relatif        
        ref = self.mg.vecteur_F;
        ref_x = ref.EXTR_COMP('DX',[],1).valeurs;
        ref_y = ref.EXTR_COMP('DY',[],1).valeurs;
        self.ref = np.sqrt(np.linalg.norm(ref_x)**2 + np.linalg.norm(ref_y)**2); 
                   
    # Calcule la norme d'un vecteur sur l'interface
    def Norme (self, vect):
        
        # Extraction des composantes du vecteur
        vect_x = vect.EXTR_COMP('DX',['GAMMA'],1).valeurs;
        vect_y = vect.EXTR_COMP('DY',['GAMMA'],1).valeurs;
        
        # Calcul de la norme
        return np.sqrt(np.linalg.norm(vect_x)**2 + np.linalg.norm(vect_y)**2); 
                  
    # Calcule le produit scalaire entre deux vecteurs sur l'interface
    def ProduitScalaire (self, vect1, vect2):
        
        # Extraction des composantes du vecteur 'vect1'
        vect1_x = vect1.EXTR_COMP('DX',['GAMMA'],1).valeurs;
        vect1_y = vect1.EXTR_COMP('DY',['GAMMA'],1).valeurs;
        
        # Extraction des composantes du vecteur 'vect2'
        vect2_x = vect2.EXTR_COMP('DX',['GAMMA'],1).valeurs;
        vect2_y = vect2.EXTR_COMP('DY',['GAMMA'],1).valeurs;
        
        # Calcul du produit scalaire
        return np.dot(vect1_x,vect2_x) + np.dot(vect1_y,vect2_y) ; 
                             
    # Calcule une combinaison lineaire de deux vecteurs    
    def CombLineaire (self, vect1, c1, vect2, c2):
                
        global o, AsterCount;
        
        AsterIter = AsterCount.next(); 
        o[AsterIter] = CREA_CHAMP (OPERATION = 'ASSE',
                                   TYPE_CHAM = 'NOEU_DEPL_R',
                                   MODELE = self.mg.modele,
                                   NUME_DDL = self.mg.numerotation_ddl,
                                   ASSE = (_F (TOUT = 'OUI',
                                               CHAM_GD = vect1,
                                               CUMUL = 'OUI',
                                               COEF_R = c1),
                                           _F (TOUT = 'OUI',
                                               CHAM_GD = vect2,
                                               CUMUL = 'OUI',
                                               COEF_R = c2))); 
                                               
        return o[AsterIter];      
              
    # Fonction de calcul de l'increment de deplacement
    # non corrige a partir de la donnee du residu d'effort
    def Calcul_Delta_u (self, r):        
        return self.mg.Resolution(r);
     
                
        
class QN_Toolbox (Optimisation_Toolbox) :
    
    def __init__ (self, modele_global) : 
    
        Optimisation_Toolbox.__init__(self, modele_global);
        
        # Indice d'iterations
        self.n = 0;
        # Stockage des contributions a l'acceleration SR1
        self.r = [];                # Residu d'effort
        self.du = [None];           # Increment de deplacement
        self.Kr = [None];           # Termes croises
        
    # Calcule le terme correctif sur le deplacement
    def Calcul_Quasi_Newton (self, r):
         
        # Calcul de l'increment de deplacement
        du = self.Calcul_Delta_u(r);
        self.r.append(r);
           
        # Pas de correction SR1 pour la premiere iteration
        if (self.n == 0):
            self.du.append(du);
            self.n = self.n + 1;
        # Correction SR1
        else :  
            for k in range(1,self.n): 
                du = self.CombLineaire(du,1.0, self.Kr[k],self.ProduitScalaire(self.r[k],du)/self.ProduitScalaire(self.r[k],self.CombLineaire(self.du[k],1.0, self.Kr[k],-1.0)));
            self.Kr.append(du);
            self.du.append(self.CombLineaire(du,1.0, du,self.ProduitScalaire(self.r[self.n],du)/self.ProduitScalaire(self.r[self.n],self.CombLineaire(self.du[self.n],1.0, du,-1.0))));
            self.n = self.n + 1;      
                    
        return self.du[-1]; 
    
    # Calcul de la mise a jour Quasi-Newton
    def Calc_Update (self, u, r):
            
        # Calcul de l'increment de deplacement corrige via SR1
        du = self.Calcul_Quasi_Newton(r);
        # Calcul du deplacement complet par combinaison lineaire
        u = self.CombLineaire(u, 1.0, du, 1.0);
        
        return u;    
    
    
    
class Aitken_Toolbox (Optimisation_Toolbox) :  
    
    def __init__ (self, modele_global, u) : 
    
        Optimisation_Toolbox.__init__(self, modele_global);
    
        # Stockage des deplacement d'interface pour la relaxation
        self.u_pred = [u,None]; # Deplacement de prediction
        self.u_corr = [u,None]; # Deplacement de correction
        # Coefficient de relaxation d'Aitken
        self.omega = 1.0;     
            
    # Mise a jour des termes de prediction stockes
    def MaJ_Prediction (self, u):
        
        self.u_pred[1] = self.u_pred[0]; 
        self.u_pred[0] = u;       
        return 0;        
                        
    # Mise a jour des termes de correction stockes
    def MaJ_Correction (self, u):
        
        self.u_corr[1] = self.u_corr[0]; 
        self.u_corr[0] = u;       
        return 0;   
            
    # Calcul du coefficient de relaxation d'Aitken    
    def Calc_Coeff_Aitken (self) :
            
        # Si le terme corrige a l'iteration "n-1" n'a pas ete stocke, le coefficient de relaxation est pris egal a un. 
        # Cela est le cas uniquement pour les deux premiere iterations.
        if self.u_corr[1] is None :            
            omega = 1.0;    
        # Sinon on calcule le coefficient en utilisant la formule Aitken's Delta Squared. 
        else :        
            r0 = self.CombLineaire(self.u_pred[0],1.0,self.u_corr[0],-1.0);
            r1 = self.CombLineaire(self.u_pred[1],1.0,self.u_corr[1],-1.0);
            dr = self.CombLineaire(r1,1.0,r0,-1.0);
            omega = self.omega*self.ProduitScalaire(r1,dr)/self.Norme(dr)**2;        
            self.omega = omega;
            
        return omega;   
            
    # Calcule de la relaxation
    def Calcul_Relaxation (self, u):
                
        omega = self.Calc_Coeff_Aitken();        
        u = self.CombLineaire(self.u_corr[0],1.0,self.CombLineaire(u,1.0*omega,self.u_corr[0],-1.0*omega),1.0);  
                            
        return u;   
                
    # Calcul de la mise a jour Aitken's Delta Squared
    def Calc_Update (self, u, r):
            
        # Calcul de l'increment de deplacement relatif au chargement residuel
        du = self.Calcul_Delta_u(r);
        # Calcul du deplacement complet (prediction)
        u = self.CombLineaire(u, 1.0, du, 1.0);
        self.MaJ_Prediction(u);
        # Calcul de la relaxation (correction)
        u = self.Calcul_Relaxation(u);
        self.MaJ_Correction(u);
        
        return u;