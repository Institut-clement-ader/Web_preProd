#!/bin/bash

## This script is organised into two major steps:


## --> First, local models files are generated using 'local.export' and 'patch.comm' templates.
##     Linux 'sed' command allows to replace 'NUM_PATCH' by the actual patch number.

## Automatic generation of local '.comm' and '.export' files
nb_patch=2;
for num_patch in `seq 1 $nb_patch`    
    do 
       n="$num_patch";
       cp local.export local$n.export;
       sed -i s/NUM_PATCH/$n/g local$n.export;
       cp patch.comm patch$n.comm;
       sed -i s/NUM_PATCH/$n/g patch$n.comm;
done


## --> Then, computations are carried out.

## Computation with MPI communications
killall ompi-server; sleep 0.25;
ompi-server -r ./server.txt; sleep 0.25;
mpirun --ompi-server file:./server.txt python ./coupling_engine.py &
mpirun --ompi-server file:./server.txt /opt/aster/bin/as_run ./global.export &
for num_patch in `seq 1 $nb_patch`    
    do      
        mpirun --ompi-server file:./server.txt /opt/aster/bin/as_run ./local$num_patch.export &       
    done